## GRPC server that writes data to kafka streaming service
