Race condition may cause kafka to restart or the pod to error out. 
If this happens, just rerun the kubectl apply -f kafka.yaml to run deployment again.

Only one new REST API endpoint was created /geolocations 

